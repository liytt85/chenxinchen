import matplotlib.pyplot as plt

def plot(huatu_flavor_dict):
    flavor_dict = eval(huatu_flavor_dict)
    day_num = []
    i = 1
    huatu_dict = {}
    for items in flavor_dict:
        day_num.append(i)
        i += 1
        for item in flavor_dict[items]:
            if (huatu_dict.has_key(item)):
                huatu_dict[item].append(flavor_dict[items][item])
            else:
                huatu_dict[item] = []
                huatu_dict[item].append(flavor_dict[items][item])
        for item in huatu_dict:
            if ( flavor_dict[items].has_key(item) == False ):
                huatu_dict[item].append(0)
    a = 1
    plt.figure(a)
    for item in huatu_dict:
        print  item
        day_num = []
        len_gh = len(huatu_dict[item])
        i = 1
        while (i <= len_gh):
            day_num.append(i)
            i += 1
        
        plt.title(item)
        a += 1
        plt.plot(day_num, huatu_dict[item], 'g^', label=item)
        
        plt.grid(True)
        plt.show()
        