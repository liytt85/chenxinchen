def new_Cf(str_flavor_need_dict, cpu_dict, mem_dict, flavor_num, str_last_pc):
	print str_flavor_need_dict, cpu_dict, mem_dict, flavor_num, str_last_pc
	flavor_need_dict = eval(str_flavor_need_dict)
	last_pc = eval(str_last_pc)
	return []